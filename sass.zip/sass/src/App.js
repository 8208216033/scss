import logo from './logo.svg';
import './App.css';
import BasicLayout from './BasicLayout';
import Mixins from './Mixins';
import Functions from './Functions';
import ColorFun from './ColorFun';

function App() {
  return (
    // <BasicLayout/>
    // <Mixins/>
    // <Functions/>
    <ColorFun/>
    
  );
}

export default App;
