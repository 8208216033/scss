import React from 'react';
import './functions.scss'

const Functions = () => {
  return (
  <>
  <div id='first'>
      
   <div className='second'></div>
  </div>
  
  </>
  )
}

export default Functions