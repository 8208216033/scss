import React from 'react'
import './colorFun.scss'

const ColorFun = () => {
  return (
    <>
    <div className='first'>
    </div>

    <div className='second'>
    </div>
    </>
  )
}

export default ColorFun