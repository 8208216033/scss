import React from "react";
import "./BasicLayout.scss";
const BasicLayout = () => {
  return (
    <>
      <div id="wrapper">
        <div id="header">
          <h1>Css Practice</h1>
        </div>
        <div id="menu">
          <ul>
            <li>
              <a href="">Home</a>
            </li>
            <li>
              <a href="">About</a>
            </li>
            <li>
              <a href="">Gallery</a>
            </li>
            <li>
              <a href="">Content</a>
            </li>
          </ul>
        </div>
        <div id="content">
          <h2>Design Basic Layout</h2>
          <p>
           
            A paragraph is a series of related sentences developing a central
            idea, called the topic. Try to think about paragraphs in terms of
            thematic unity: a paragraph is a sentence or a group of sentences
            that supports one central, unified idea. Paragraphs add one idea at
            a time to your broader argument.
          </p>
          <p>
            A paragraph is a series of related sentences developing a central
            idea, called the topic. Try to think about paragraphs in terms of
            thematic unity: a paragraph is a sentence or a group of sentences
            that supports one central, unified idea. Paragraphs add one idea at
            a time to your broader argument.
          </p>
        </div>
        <div id="sidebar">
            <ul>
            <li>
              <a href="">Home</a>
            </li>
            <li>
              <a href="">About</a>
            </li>
            <li>
              <a href="">Gallery</a>
            </li>
            <li>
              <a href="">Content</a>
            </li>
            </ul>
        </div>
        <div id="footer">
            My webside
        </div>
      </div>
    </>
  );
};

export default BasicLayout;
