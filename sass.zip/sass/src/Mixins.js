import React from 'react'
import './mixins.scss'
const Mixins = () => {
  return (
 <>
 <div id="paragraph1">
 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has 
 
</div>
<br/>

<div id="second">
Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
when an unknown printer took a galley of type and scrambled it to make a type specimen book.
 It has survived not only five centuries, but also the leap into electronic typesetti
</div>
<br/>

<div id="third">

</div>
 </>
  )
}

export default Mixins